
document.addEventListener("DOMContentLoaded", function(){
    document.getElementById("autos").addEventListener("click",function(){
        localStorage.setItem("catID", 101);
        location.href = "products.html"
    });
    document.getElementById("juguetes").addEventListener("click", function(){
        localStorage.setItem("catID", 102);
        location.href = "products.html"
    });
    document.getElementById("muebles").addEventListener("click", function(){
        localStorage.setItem("catID", 103);
        location.href = "products.html"
    });
});
let categorias = [document.getElementById('cats')]
function filtrar(array){
    let desde = JSON.parse(document.getElementById('desde').value);
    let hasta = JSON.parse(document.getElementById('hasta').value);
    let filtrado = array.products.filter(producto=> array.products.cost >= desde && array.products.cost <= hasta);
    mostrar(filtrado)};




document.addEventListener('DOMContentLoaded', ()=>{
    document.getElementById('filtrar').addEventListener("click",()=>{
        filtrar(categorias)
    })
    });